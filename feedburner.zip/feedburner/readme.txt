=== Feed Burner Widget ===
Contributors: pa1
Donate link: http://example.com/
Tags: google feed, feeds, feedburner widget,feedburner email subscription form 
Requires at least: 2.7
Tested up to: 4.5.3
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Here is a short description of the plugin.  This should be no more than 150 characters.  No markup here.

== Description ==

 free feedburner email subscription on your site By google .



== Installation ==

Plugin easy to install.

e.g.

    Upload the plugin files to the /wp-content/plugins/plugin-name directory, or install the plugin through the WordPress plugins screen directly.
    Activate the plugin through the 'Plugins' screen in WordPress

== Frequently Asked Questions ==



== Screenshots ==


== Changelog ==



== A brief Markdown Example ==


`<?php code(); // goes in backticks ?>`